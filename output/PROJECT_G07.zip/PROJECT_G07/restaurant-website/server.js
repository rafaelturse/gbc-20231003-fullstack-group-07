const express = require('express')
const app = express()
const HTTP_PORT = process.env.PORT || 8080
const path = require('path')
const { engine } = require('express-handlebars')
const session = require('express-session')
const mongoose = require("mongoose")


app.use(express.urlencoded({extended: true}))

app.engine('.hbs', engine ({extname: '.hbs'}))
app.set('views', './views');
app.set('view engine', '.hbs')

app.use(express.static('assets'))

//configure the express session
app.use(session({
    secret: 'key configure', //any random string used for configuring the session
    resave: false,
    saveUninitialized: true,
    // cookie: { secure: true }
}))


/// --------------
// DATABASE : Connecting to database and setting up schemas/models (tables)
/// --------------

const CONNECTION_STRING = "mongodb+srv://quervolvh:eNCFrrrMIklQTJ2Q@t440-cluster.pgdxfdw.mongodb.net/t440-work?retryWrites=true&w=majority";

mongoose.connect(CONNECTION_STRING);

const db = mongoose.connection;
db.on("error", console.error.bind(console, "Error connecting to database: "));
db.once("open", () => { console.log("Mongo DB connected successfully.");});

// schemas
const MenuItemSchema = mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    price: {
        type: String,
        required: true,
    },
    description: {
        type: String
    },
    photo: {
        type: String,
        required: true,
    }
});
const OrderItemSchema = mongoose.Schema({
    menu_item: {
        type: String,
        required: true,
    },
    menu_item_id: {
        type: String,
        required: true,
    },
    order_number: {
        type: String,
        required: true,
    },
    order_ref: {
        type: String,
        required: true
    },
    order_status: {
        type: String,
        require: true,
    },
    order_date: {
        type: String,
        required: true
    },
    order_photo: {
        type: String,
        required: true
    },
    proof_photo: {
        type: String
    },
    order_driver: {
        type: String
    },
    order_price: {
        type: Number,
        required: true
    },
    address: {
        type: String,
        required: true
    },
    created_at: {
        type: String,
        required: true,
        default: new Date()
    }
});
const Menu = mongoose.model('Menu', MenuItemSchema);
const Order = mongoose.model('Order', OrderItemSchema);



// endpoints
app.get('/', async (req, res) => {
    try {
        const orders = await Order.find().lean().exec()
        res.render('orders', {layout: false, orders: orders.reverse()})
    } catch (err) {
        res.send(`No orders found`)
    }
    
})

app.get('/past-orders', async (req, res) => {
    try {
        const orders = await Order.find({order_status: 'DELIVERED'}).lean().exec()
        res.render('orders', {layout: false , orders: orders.reverse()})
    } catch (err) {
        res.send(`No orders found`)
    }
   
})

app.get('/current-orders', async (req, res) => {
    try {
        const orders = await  Order.find({order_status: {$ne : 'DELIVERED'}}).lean().exec()
        res.render('orders', {layout: false , orders: orders.reverse()})        
    } catch (err) {
        res.render('orders', {layout: false, error: 'No orders found'})
    }

})

app.post('/customers', async (req, res) => {
    try{
        const customer = req.body.name
        
        const customerOrders = await Order.find({ customer_name: customer}).lean().exec()
        
        res.render('orders', {layout: false , orders: customerOrders.reverse()})    
    } catch {
        res.send(`No customer with that name found`)
    }
   
})

app.post('/update/:id', async (req, res) => {
    try{
        const id = req.params.id
        const newStatus = req.body.status
        await Order.findOneAndUpdate({order_ref: id}, {order_status: newStatus })
        res.redirect('/')
    } catch (err) {
        console.log(err)
        res.send('Could not update, something is wrong')
    }
})



const onHttpStart = () => {
    console.log(`The web server has started at http://localhost:${HTTP_PORT}`);
    console.log("Press CTRL+C to stop the server.");
};
app.listen(HTTP_PORT, onHttpStart);